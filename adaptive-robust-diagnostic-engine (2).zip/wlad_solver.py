"""
Weighted Least Absolute Deviation (WLAD) estimation via Linear Programming.
Solves: min_beta sum w_i |y_i - x_i' beta|
"""
import numpy as np
from scipy.optimize import linprog


class WLADSolver:
    """
    Solver for Weighted Least Absolute Deviation regression.
    Uses interior-point linear programming formulation.
    """
    def __init__(self, max_iter=1000, tol=1e-6, ridge_penalty=1e-8):
        self.max_iter = max_iter
        self.tol = tol
        self.ridge_penalty = ridge_penalty
        self.coef_ = None
        self.intercept_ = None
        self.residuals_ = None
        self.fitted_ = None
        self.n_iter_ = None

    def fit(self, X, y, weights=None, warm_start=None):
        """
        Fit WLAD regression.

        Parameters
        ----------
        X : array, shape (n, p)
            Design matrix
        y : array, shape (n,)
            Response vector
        weights : array, shape (n,) or None
            Observation weights. If None, all weights = 1.
        warm_start : array, shape (p+1,) or None
            Initial values for [intercept, coef].

        Returns
        -------
        self : WLADSolver
        """
        X = np.asarray(X, dtype=np.float64)
        y = np.asarray(y, dtype=np.float64)
        n, p = X.shape

        if weights is None:
            weights = np.ones(n)
        weights = np.asarray(weights, dtype=np.float64)

        # Add intercept column
        X_aug = np.column_stack([np.ones(n), X])
        p_aug = p + 1

        # Standard LP formulation for LAD
        # Variables: [beta_0, beta_1, ..., beta_p, u_1, ..., u_n, v_1, ..., v_n]
        c = np.concatenate([
            np.zeros(p_aug),
            weights,
            weights
        ])

        # Equality constraints: y_i = x_i' beta + u_i - v_i
        A_eq = np.zeros((n, p_aug + 2 * n))
        for i in range(n):
            A_eq[i, :p_aug] = X_aug[i, :]
            A_eq[i, p_aug + i] = 1.0
            A_eq[i, p_aug + n + i] = -1.0

        b_eq = y
        bounds = [(None, None)] * p_aug + [(0, None)] * (2 * n)

        # Add ridge penalty for numerical stability
        if self.ridge_penalty > 0:
            ridge_matrix = np.sqrt(self.ridge_penalty) * np.eye(p_aug)
            A_eq_ridge = np.zeros((p_aug, p_aug + 2 * n))
            A_eq_ridge[:, :p_aug] = ridge_matrix
            b_eq_ridge = np.zeros(p_aug)
            A_eq = np.vstack([A_eq, A_eq_ridge])
            b_eq = np.concatenate([b_eq, b_eq_ridge])

        # Warm start
        x0 = None
        if warm_start is not None:
            warm_start = np.asarray(warm_start)
            if len(warm_start) == p_aug:
                beta_init = warm_start
                resid = y - X_aug @ beta_init
                u_init = np.maximum(0, resid)
                v_init = np.maximum(0, -resid)
                x0 = np.concatenate([beta_init, u_init, v_init])

        # Solve using HiGHS (modern LP solver)
        # Note: 'highs' method doesn't accept 'tol' option
        result = linprog(
            c,
            A_eq=A_eq,
            b_eq=b_eq,
            bounds=bounds,
            method='highs',
            options={'maxiter': self.max_iter}
        )

        if not result.success:
            # Fallback
            result = linprog(
                c,
                A_eq=A_eq,
                b_eq=b_eq,
                bounds=bounds,
                method='highs-ipm',
                options={'maxiter': self.max_iter}
            )

        if not result.success:
            raise RuntimeError(f"WLAD solver failed: {result.message}")

        # Extract coefficients
        solution = result.x
        beta = solution[:p_aug]

        self.intercept_ = beta[0]
        self.coef_ = beta[1:]
        self.fitted_ = X_aug @ beta
        self.residuals_ = y - self.fitted_
        self.n_iter_ = result.nit if hasattr(result, 'nit') else None

        return self

    def predict(self, X):
        """Predict using WLAD model."""
        X = np.asarray(X, dtype=np.float64)
        return self.intercept_ + X @ self.coef_

    def score(self, X, y, weights=None):
        """Return weighted mean absolute error."""
        y_pred = self.predict(X)
        resid = np.abs(y - y_pred)
        if weights is None:
            return -np.mean(resid)
        return -np.average(resid, weights=weights)
