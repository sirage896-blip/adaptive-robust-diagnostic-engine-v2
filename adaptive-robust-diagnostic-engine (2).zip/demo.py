"""
Fixed Demo: Adaptive Robust Diagnostic Engine
Uses properly scaled synthetic data to avoid numerical issues.
"""
import numpy as np
import matplotlib.pyplot as plt
from engine import AdaptiveRobustDiagnosticEngine

np.random.seed(42)

print("=" * 70)
print("ADAPTIVE ROBUST DIAGNOSTIC ENGINE - FIXED DEMO")
print("=" * 70)
print()

# Generate realistic synthetic data with good scale
n = 200
p = 2

# Clean predictors: reasonable scale, moderate correlation
mean = [50.0, 30.0]
cov = [[225.0, 45.0], [45.0, 144.0]]  # std ~15, 12; corr ~0.25
X_clean = np.random.multivariate_normal(mean, cov, size=n)

# True parameters
beta_true = np.array([10.0, 0.5, -0.3])

# Clean response with moderate noise (std ~5)
y_clean = beta_true[0] + X_clean[:, 0] * beta_true[1] + X_clean[:, 1] * beta_true[2]
y_clean += np.random.normal(0, 5, n)

# Inject 10% leverage + vertical outliers
n_outliers = int(0.10 * n)
outlier_idx = np.random.choice(n, size=n_outliers, replace=False)

X_contaminated = X_clean.copy()
y_contaminated = y_clean.copy()

# Leverage contamination: shift to extreme region
X_contaminated[outlier_idx, 0] = np.random.normal(100, 5, n_outliers)
X_contaminated[outlier_idx, 1] = np.random.normal(80, 4, n_outliers)

# Vertical contamination: add large errors
y_contaminated[outlier_idx] += np.random.normal(25, 10, n_outliers)

print(f"Generated data: n={n}, p={p}")
print(f"True parameters: intercept={beta_true[0]:.3f}, β1={beta_true[1]:.3f}, β2={beta_true[2]:.3f}")
print(f"Injected {n_outliers} contaminated observations ({100*n_outliers/n:.0f}%)")
print(f"X range: [{X_contaminated[:,0].min():.1f}, {X_contaminated[:,0].max():.1f}]")
print(f"y range: [{y_contaminated.min():.1f}, {y_contaminated.max():.1f}]")
print()

# Run engine with reduced bootstrap for speed
engine = AdaptiveRobustDiagnosticEngine(
    coverage=0.5,
    alpha=0.05,
    n_bootstrap=200,
    lowess_frac=0.3,
    random_state=42,
    verbose=True
)

results = engine.fit(X_contaminated, y_contaminated)

# Print summary
feature_names = ["X1", "X2"]
engine.summary(feature_names=feature_names)

# Compare with true parameters
print()
print("TRUE vs ESTIMATED PARAMETERS:")
print("-" * 65)
print(f"{'Parameter':<12} {'True':>10} {'WLAD':>10} {'CI Lower':>12} {'CI Upper':>12}")
print(f"{'Intercept':<12} {beta_true[0]:>10.3f} {results['intercept']:>10.3f} "
      f"{results['intercept_interval'][0]:>12.3f} {results['intercept_interval'][1]:>12.3f}")
for j in range(p):
    print(f"{'X'+str(j+1):<12} {beta_true[j+1]:>10.3f} {results['coefficients'][j]:>10.3f} "
          f"{results['confidence_intervals'][j,0]:>12.3f} {results['confidence_intervals'][j,1]:>12.3f}")

# Plot LBEP
fig, ax = engine.plot_lbep(save_path="lbep_demo_fixed.png")
plt.show()

print()
print("=" * 70)
print("Demo complete! Plot saved to lbep_demo_fixed.png")
print("=" * 70)
